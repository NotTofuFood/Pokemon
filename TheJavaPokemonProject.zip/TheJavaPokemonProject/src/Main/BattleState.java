package Main;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JPanel;

public class BattleState extends JPanel implements KeyListener{
	/**
	 * 
	 */
	private static final long serialVersionUID = -5687398511834314921L;

	BufferedImage pokemon;
	BufferedImage loudred = null;
	BufferedImage pik = null;
	BufferedImage meta = null;
	BufferedImage vene = null;
	BufferedImage trainer = null;
	BufferedImage fire = null;
	BufferedImage charz = null;
	BufferedImage box = null;
	PokemonGame pg = new PokemonGame();
	String move1L = "";
	String move2L = "";
	String move1P = "";
	String move2P = "";
	String move1M = "";
	String move2M = "";
	String move1V = "";
	String move2V = "";
	boolean charD = false;
	boolean changeText = false;
	int charHP = 76;

	int pikHP = 35;
	int loudredHP = 84;
	int metapodHP = 50;
	int veneHP = 80;
	public BattleState() {
		addKeyListener(this);
		try {
			loudred = ImageIO.read(getClass().getResource("/Sprites/loudred.png"));
			pik = ImageIO.read(getClass().getResource("/Sprites/pickachu.png"));
			meta = ImageIO.read(getClass().getResource("/Sprites/metapod.png"));
			vene = ImageIO.read(getClass().getResource("/Sprites/venusaur.png"));
			trainer = ImageIO.read(getClass().getResource("/Sprites/trainer.png"));
			charz = ImageIO.read(getClass().getResource("/Sprites/char.png"));
			fire = ImageIO.read(getClass().getResource("/Sprites/fire.png"));
			box = ImageIO.read(getClass().getResource("/Sprites/box.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		setFocusable(true);
		setFocusTraversalKeysEnabled(false);
		setBackground(Color.WHITE);
		addKeyListener(this);
	}
	public void paintComponent(Graphics g) {
	super.paintComponent(g);

	g.drawImage(fire, 500, 50, null);
	g.drawImage(charz, 500, 200, null);
	g.drawImage(box, 400, 400, null);
	if(charHP <=0) {
		g.drawString("You Defeated Trainer Andrew's Charizard!",450,550);
	}
	ChoosePokemon cp = new ChoosePokemon();
	if(cp.getPokemon()==1) {
		g.drawImage(loudred, 100,500, null);

		if(!changeText) {
			g.drawString("What will Loudred Do?", 450,450);
			}
			if(changeText) {
				g.drawString("Charizard Used Fire Spin! and Loudred used " + move1L + move2L+"!", 450,450);
				if(charHP <=0) {
					g.drawString("You Defeated Trainer Andrew's Charizard! Press Enter!",450,500);
					pg.updgrade();
					Thread t = new Thread();
					try {
						t.sleep(2000);
						Title t22 = new Title();
						t22.GameState();
					} catch (InterruptedException e1) {
				
						e1.printStackTrace();
					}
					charD=true;
				}
				}
			g.drawString("Loudred's HP: " + loudredHP, 750,450);
			g.drawString("Charizard's HP: " + charHP, 750,550);
			JButton attack = new JButton("Bite!");
			add(attack);
			attack.setVisible(true);
			attack.setBounds(450, 500, 100,50);
			JButton attack2 = new JButton("UpRoar!");
			add(attack2);
			attack2.setVisible(true);
			attack2.setBounds(450, 550, 150,50);
			attack.addActionListener(new ActionListener()
					{
					public void actionPerformed(ActionEvent e) {
						Random damage = new Random();
						move1L = "Bite";
						int i = damage.nextInt(20)+20;
						charHP = charHP  - 18;
						loudredHP = loudredHP - i;
						changeText = true;
						if(charHP <=0) {
							g.drawString("You Defeated Trainer Andrew's Charizard!",450,550);
						}
						repaint();
					}
					}
					);
			attack2.addActionListener(new ActionListener()
			{
			public void actionPerformed(ActionEvent e) {
				move1L = "Uproar";
				Random damage = new Random();
				int i = damage.nextInt(10 + 2) + 10;
				charHP = charHP  - i;
				loudredHP = loudredHP - 10;
				changeText = true;
				if(charHP <=0) {
					g.drawString("You Defeated Trainer Andrew's Charizard!",450,550);
				}
				repaint();
			}
			}
			);
		
		repaint();
	}
	if(cp.getPokemon()==2) {
		g.drawImage(pik, 100,500, null);
		if(!changeText) {
		g.drawString("What will Pikachu Do?", 450,450);
		}
		if(changeText) {
			g.drawString("Charizard Used Fire Spin! and Pikachu used " + move1P + move2P + "!", 450,450);
			if(charHP <=0) {
				g.drawString("You Defeated Trainer Andrew's Charizard! Press Enter!",450,500);
				pg.updgrade();
				Thread t = new Thread();
				try {
					t.sleep(2000);
					Title t22 = new Title();
					t22.GameState();
				} catch (InterruptedException e1) {
			
					e1.printStackTrace();
				}
				charD=true;
			}
			}
		g.drawString("Pikachu's HP: " + pikHP, 750,450);
		g.drawString("Charizard's HP: " + charHP, 750,550);
		JButton attack = new JButton("Slam!");
		add(attack);
		attack.setVisible(true);
		attack.setBounds(450, 500, 100,50);
		JButton attack2 = new JButton("ThunderBolt!");
		add(attack2);
		attack2.setVisible(true);
		attack2.setBounds(450, 550, 150,50);
		attack.addActionListener(new ActionListener()
				{
				public void actionPerformed(ActionEvent e) {
					move1P = "Slam";
					Random damage = new Random();
					int i = damage.nextInt(3)+2;
					charHP = charHP  - 12;
					pikHP = pikHP - i;
					changeText = true;
					if(charHP <=0) {
						g.drawString("You Defeated Trainer Andrew's Charizard!",450,550);
						Thread t = new Thread();
						try {
							t.sleep(2000);
							Title t22 = new Title();
							t22.GameState();
						} catch (InterruptedException e1) {
					
							e1.printStackTrace();
						}
						charD=true;
					}
					repaint();
				}
				}
				);
		attack2.addActionListener(new ActionListener()
		{
		public void actionPerformed(ActionEvent e) {
			move1P = "Thunderbolt";
			Random damage = new Random();
			int i = damage.nextInt(10 + 7) + 10;
			charHP = charHP  - i;
			pikHP = pikHP - 10;
			changeText = true;
			if(charHP <=0) {
				g.drawString("You Defeated Trainer Andrew's Charizard!",450,550);
				charD=true;
			}
			repaint();
		}
		}
		);
		repaint();
	}
	if(cp.getPokemon()==3) {
		g.drawImage(meta,100,500, null);
		if(!changeText) {
			g.drawString("What will Metapod Do?", 450,450);
			}
			if(changeText) {
				g.drawString("Charizard Used Fire Spin! and Metapod used Harden! (Metapod's defense Rose)", 450,450);
				if(charHP <=0) {
					pg.updgrade();
					g.drawString("You Defeated Trainer Andrew's Charizard! Press Enter!",450,500);
					Thread t = new Thread();
					try {
						t.sleep(2000);
						Title t22 = new Title();
						t22.GameState();
					} catch (InterruptedException e1) {
				
						e1.printStackTrace();
					}
					charD=true;
				}
				}
			g.drawString("Metapod's HP: " + metapodHP, 750,450);
			g.drawString("Charizard's HP: " + charHP, 750,550);
			JButton attack = new JButton("Harden!");
			add(attack);
			attack.setVisible(true);
			attack.setBounds(450, 500, 100,50);
			attack.addActionListener(new ActionListener()
					{
				
					public void actionPerformed(ActionEvent e) {
						charHP = charHP;
						metapodHP = metapodHP - 35;
						changeText = true;
						if(charHP <=0) {
							g.drawString("You Defeated Trainer Andrew's Charizard!",450,550);
							charD=true;
						}
						repaint();
					}
					}
					);

	}
	if(cp.getPokemon()==4) {
		g.drawImage(vene, 100,500, null);
		if(!changeText) {
			g.drawString("What will Venesaur Do?", 450,450);
			}
			if(changeText) {
				g.drawString("Charizard Used Fire Spin! and Venesaur used " + move1V + move2V + "!", 450,450);
				if(charHP <=0) {
					pg.updgrade();
					g.drawString("You Defeated Trainer Andrew's Charizard! Press Enter!",450,500);
					Thread t = new Thread();
					try {
						t.sleep(2000);
						Title t22 = new Title();
						t22.GameState();
					} catch (InterruptedException e1) {
				
						e1.printStackTrace();
					}
					charD=true;
				}
				}
			g.drawString("Venesaur's HP: " + veneHP, 750,450);
			g.drawString("Charizard's HP: " + charHP, 750,550);
			JButton attack = new JButton("Tackle!");
			add(attack);
			attack.setVisible(true);
			attack.setBounds(450, 500, 100,50);
			JButton attack2 = new JButton("Take Down!");
			add(attack2);
			attack2.setVisible(true);
			attack2.setBounds(450, 550, 150,50);
			attack.addActionListener(new ActionListener()
					{
					public void actionPerformed(ActionEvent e) {
						move1V = "Tackle";
						Random damage = new Random();
						int i = damage.nextInt(7)+7;
						charHP = charHP  - 18;
						veneHP = veneHP - i;
						changeText = true;
						if(charHP <=0) {
							g.drawString("You Defeated Trainer Andrew's Charizard!",450,550);
						}
						repaint();
					}
					}
					);
			attack2.addActionListener(new ActionListener()
			{
			public void actionPerformed(ActionEvent e) {
				move1V = "Take Down";
				Random damage = new Random();
				int i = damage.nextInt(5) + 10;
				charHP = charHP  - i;
				veneHP = veneHP - 9;
				changeText = true;
				if(charHP <=0) {
					
					g.drawString("You Defeated Trainer Andrew's Charizard!",450,550);
				}
				repaint();
			}
			}
			);
		repaint();
	}
	}
	public void keyTyped(KeyEvent e) {
	
	}


	public void keyPressed(KeyEvent e) {

	}


	public void keyReleased(KeyEvent e) {

	}
}
