package Main;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

public class CenterState extends JPanel implements KeyListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 3241094327750750904L;
	public static int x=600;
	public static int y=600;
	BufferedImage player = null;
	BufferedImage grass = null;
	BufferedImage center = null;
	BufferedImage pokemon = null;
	BufferedImage loudredImage = null;
	boolean choose;
	boolean pickachu = false;
	String person = null;
	boolean loudred = false;
	boolean metapod = false;
	boolean vene = false;
	boolean canenter = true;
	public CenterState() {
		x=100;
		y=500;
		Thread t = new Thread();
		try {
		//	if(GameState==1) {
			t.sleep(10);
			getPokemon();
		//	}
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
		choose = true;
		addKeyListener(this);
		setFocusable(true);
		setFocusTraversalKeysEnabled(false);
		requestFocusInWindow();
		revalidate();
		setBackground(Color.DARK_GRAY);
		try {
			setLeft();
			setBackground();
			setUp();
		} catch (IOException e) {

			e.printStackTrace();
		}
	}
	public void setBackground() throws IOException {
		grass = ImageIO.read(getClass().getResource("/Sprites/grass_tile.png"));
		center = ImageIO.read(getClass().getResource("/Sprites/InsideCenter.png"));
	
	}
	public void setLeft() throws IOException {
		x=x-60;
		player = ImageIO.read(getClass().getResource("/Sprites/left.png"));
	}
	public void setRight() throws IOException {
		x=x+60;
		player = ImageIO.read(getClass().getResource("/Sprites/right.png"));
	}
	public void setUp() throws IOException {
		y=y+60;
		player = ImageIO.read(getClass().getResource("/Sprites/front.png"));
	}
	public void setDown() throws IOException {
		y=y-60;
		player = ImageIO.read(getClass().getResource("/Sprites/back.png"));
	}
	public void paintComponent(Graphics g) {
		
		super.paintComponent(g);
		//Draw Player & Background
		g.drawImage(center,0,0,null);
		g.fillRect(400, 600, 64,64);
	//	g.drawImage(center, 500, 300, null);
		if(loudred) {
			try {
				pokemon = ImageIO.read(getClass().getResource("/Sprites/loudred.png"));
				g.drawImage(pokemon, x+10, y, null);
				repaint();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
		if(pickachu) {
			try {
				pokemon = ImageIO.read(getClass().getResource("/Sprites/pickachu.png"));
				g.drawImage(pokemon, x+10, y, null);
				repaint();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
		if(metapod) {
			try {
				pokemon = ImageIO.read(getClass().getResource("/Sprites/metapod.png"));
				g.drawImage(pokemon, x+10, y, null);
				repaint();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
		if(vene) {
			try {
				pokemon = ImageIO.read(getClass().getResource("/Sprites/venusaur.png"));
				g.drawImage(pokemon, x+10, y, null);
				repaint();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
		g.drawImage(player, x, y, null);
	
		Rectangle player = new Rectangle(x,y,32,32);
		Rectangle door = new Rectangle(400,600,64,64);
		//g.setColor(Color.green);
		//g.fillRect(0,0,1200,500);
		Rectangle center = new Rectangle(0,0,1200,500);
		//Collision
		if(player.intersects(center) && choose) {
			ChoosePokemon cp = new ChoosePokemon();
			String[] args = null; 
			cp.main(args);
			choose = false;
		}
		if(player.intersects(door) && canenter) {
			Title t = new Title();
			t.GameState();
			canenter = false;
			x=0;
			y=0;
		}


	
	
		
 
		repaint();
	}

	public void keyTyped(KeyEvent e) {

	}
	public void call() {
		CenterState pg = new CenterState();
	}
	public void keyPressed(KeyEvent e) {
		
		if(e.getKeyCode()==KeyEvent.VK_RIGHT) {
			try {
				canenter = true;
				getPokemon();
				setRight();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			repaint();
		} 
		if(e.getKeyCode()==KeyEvent.VK_LEFT) {
			try {
				canenter = true;
				getPokemon();
				setLeft();
			} catch (IOException e1) {
			
				e1.printStackTrace();
			}
			repaint();
		} 
		if(e.getKeyCode()==KeyEvent.VK_UP) {
			try {
				canenter = true;
				getPokemon();
				setDown();
	
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		
			repaint();
		} 
		if(e.getKeyCode()==KeyEvent.VK_DOWN) {
			try {
				canenter = true;
				getPokemon();
				setUp();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			repaint();
		} 
	}

	public void keyReleased(KeyEvent e) {

	}
	
	public void getPokemon() {
		ChoosePokemon cp = new ChoosePokemon();
		if(cp.getPokemon()==1) {
			loudred = true;
			repaint();
		}
		if(cp.getPokemon()==2) {
			pickachu = true;
			repaint();
		}
		if(cp.getPokemon()==3) {
			metapod = true;
			repaint();
		}
		if(cp.getPokemon()==4) {
			vene = true;
			repaint();
		}
}
}
