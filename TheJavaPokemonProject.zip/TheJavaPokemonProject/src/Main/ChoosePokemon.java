package Main;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;



public class ChoosePokemon {
	public static JLabel loudredLable; 
	public static ImageIcon LoudredIcon;
	static int pokemon = 0;
public static void main(String[] args) {
	LoudredIcon = new ImageIcon(ChoosePokemon.class.getResource("/Sprites/AllPokemon.png"));
	loudredLable = new JLabel(LoudredIcon);
	
    JFrame f = new JFrame("Choose Your Pokemon!");
    f.setVisible(true);
    f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    f.setSize(500, 500);
    f.setLocation(430, 100);

    JPanel panel = new JPanel();
    panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS)); 

    f.add(panel);
    
    JLabel lbl = new JLabel("Choose One Pokemon.");
    lbl.setAlignmentX(Component.CENTER_ALIGNMENT);


    panel.add(lbl);

    String[] choices = { "Loudred","Pikachu","Metapod","Venusaur" };

    final JComboBox<String> cb = new JComboBox<String>(choices);

    cb.setMaximumSize(cb.getPreferredSize()); 
    cb.setAlignmentX(Component.CENTER_ALIGNMENT);
 
    panel.add(cb);
    pokemon = 1;
    cb.addItemListener(new ItemListener() {
    	
        public void itemStateChanged(ItemEvent ie) {
        	String  x = String.valueOf(cb.getSelectedItem());
        	System.out.println(x);
        	if(x == "Loudred") {
        		pokemon = 1;
        		getPokemon();
        	}
        	if(x == "Pikachu") {
        		pokemon = 2;
        		getPokemon();
        	}
        	if(x == "Metapod") {
        		pokemon = 3;
        		getPokemon();
        	}
        	if(x == "Venusaur") {
        		pokemon = 4;
        		getPokemon();
        	}
        }
    });
    JButton bt = new JButton("Ok");
    bt.addActionListener( new ActionListener()
    {
        public void actionPerformed(ActionEvent e)
        {
         f.dispose();

        }
    });
    bt.setAlignmentX(Component.CENTER_ALIGNMENT); 
    panel.add(bt);
    f.add(loudredLable, BorderLayout.SOUTH);
    
    f.setVisible(true); 

    }
	public static int getPokemon() {
		if(pokemon==1) {
			//System.out.println("Loudred");
		}
		if(pokemon==2) {
		//	System.out.println("Pik");
		}
		if(pokemon==3) {
		//	System.out.println("Meta");
		}
		if(pokemon==4) {
		//	System.out.println("Ven");
		}
		return pokemon;
	}

}