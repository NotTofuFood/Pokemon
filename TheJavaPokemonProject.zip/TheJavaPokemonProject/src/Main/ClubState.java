package Main;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

public class ClubState extends JPanel implements KeyListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 3241094327750750904L;
	public static int x=600;
	public static int y=600;
	BufferedImage player = null;
	BufferedImage grass = null;
	BufferedImage center = null;
	BufferedImage pokemon = null;
	BufferedImage loudredImage = null;
	BufferedImage jiggle = null;
	boolean has = false; 
	boolean choose;
	boolean pickachu = false;
	String person = null;
	boolean loudred = false;
	boolean metapod = false;
	boolean vene = false;
	boolean canenter = true;
	public ClubState() {
		if(has) {
		x=100;
		y=500;
		}
		Thread t = new Thread();
		try {
		//	if(GameState==1) {
			t.sleep(10);
			getPokemon();
		//	}
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
		choose = true;
		addKeyListener(this);
		setFocusable(true);
		setFocusTraversalKeysEnabled(false);
		requestFocusInWindow();
		revalidate();
		setBackground(Color.DARK_GRAY);
		try {
			setLeft();
			setBackground();
			setUp();
		} catch (IOException e) {

			e.printStackTrace();
		}
	}
	public void setBackground() throws IOException {
		grass = ImageIO.read(getClass().getResource("/Sprites/grass_tile.png"));
	//	center = ImageIO.read(getClass().getResource("/Sprites/club.png"));
		jiggle = ImageIO.read(getClass().getResource("/Sprites/jigglypuff.png"));
	}
	public void setLeft() throws IOException {
		x=x-60;
		player = ImageIO.read(getClass().getResource("/Sprites/left.png"));
	}
	public void setRight() throws IOException {
		x=x+60;
		player = ImageIO.read(getClass().getResource("/Sprites/right.png"));
	}
	public void setUp() throws IOException {
		y=y+60;
		player = ImageIO.read(getClass().getResource("/Sprites/front.png"));
	}
	public void setDown() throws IOException {
		y=y-60;
		player = ImageIO.read(getClass().getResource("/Sprites/back.png"));
	}
	public void paintComponent(Graphics g) {
		
		super.paintComponent(g);
		//Draw Player & Background
		if(has) {
			Title t = new Title();
			t.GameState();
		}
		g.drawImage(player, x, y, null);
		g.drawImage(jiggle, 100,50,null);
		Rectangle player = new Rectangle(x,y,32,32);

		Rectangle jiggly = new Rectangle(100,50,120,120);
		//Collision
		if(player.intersects(jiggly) && !has) {
			has=true;
			Title t = new Title();
			t.bs2();
			
		}

	
	
		
 
		repaint();
	}
 
	public void keyTyped(KeyEvent e) {

	}
	public void call() {
		ClubState pg = new ClubState();
	}
	public void keyPressed(KeyEvent e) {
		
		if(e.getKeyCode()==KeyEvent.VK_RIGHT) {
			try {
				canenter = true;
				getPokemon();
				setRight();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			repaint();
		} 
		if(e.getKeyCode()==KeyEvent.VK_LEFT) {
			try {
				canenter = true;
				getPokemon();
				setLeft();
			} catch (IOException e1) {
			
				e1.printStackTrace();
			}
			repaint();
		} 
		if(e.getKeyCode()==KeyEvent.VK_UP) {
			try {
				canenter = true;
				getPokemon();
				setDown();
	
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		
			repaint();
		} 
		if(e.getKeyCode()==KeyEvent.VK_DOWN) {
			try {
				canenter = true;
				getPokemon();
				setUp();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			repaint();
		} 
	}

	public void keyReleased(KeyEvent e) {

	}
	
	public void getPokemon() {
		ChoosePokemon cp = new ChoosePokemon();
		if(cp.getPokemon()==1) {
			loudred = true;
			repaint();
		}
		if(cp.getPokemon()==2) {
			pickachu = true;
			repaint();
		}
		if(cp.getPokemon()==3) {
			metapod = true;
			repaint();
		}
		if(cp.getPokemon()==4) {
			vene = true;
			repaint();
		}
}
}
