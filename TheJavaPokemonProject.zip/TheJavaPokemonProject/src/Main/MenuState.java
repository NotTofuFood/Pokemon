package Main;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

public class MenuState extends JPanel implements KeyListener{
	/**
	 * 
	 */
	private static final long serialVersionUID = -5687398511834314921L;
	int tt = 1;
	boolean enter;
	BufferedImage pokemon;
	BufferedImage title;
	BufferedImage start;
	public MenuState() {
		addKeyListener(this);
		try {
			pokemon = ImageIO.read(getClass().getResource("/Sprites/AllPokemon.png"));
			title = ImageIO.read(getClass().getResource("/Sprites/title.png"));
			start = ImageIO.read(getClass().getResource("/Sprites/enter.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		setFocusable(true);
		setFocusTraversalKeysEnabled(false);
		setBackground(Color.DARK_GRAY);
		enter = true;
	}
	public void paintComponent(Graphics g) {
	super.paintComponent(g);

	//Font title = new Font("Arial",20,80);
	//g.setFont(title);
	//g.drawString("TheJavaPokemonProject", 100, 200);
	g.drawImage(pokemon, 100,100, null);
	g.drawImage(this.title, 700,100, null);
	g.drawImage(start, 100,600, null);
	}
	public void keyTyped(KeyEvent e) {
	
	}


	public void keyPressed(KeyEvent e) {
		
		if(e.getKeyCode()==KeyEvent.VK_ENTER) {
			Title t = new Title();
			t.GameState();
			System.out.println("ChangeState");
			tt=tt+1;
			
		} else {
			
		}
		}
	


	public void keyReleased(KeyEvent e) {

	}
}
