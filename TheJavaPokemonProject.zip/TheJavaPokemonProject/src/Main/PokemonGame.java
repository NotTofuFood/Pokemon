package Main;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

public class PokemonGame extends JPanel implements KeyListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 3241094327750750904L;
	public static int x=600;
	public static int y=60;
	BufferedImage player = null;
	BufferedImage grass = null;
	BufferedImage center = null;
	BufferedImage loudred = null;
	BufferedImage pik = null;
	BufferedImage meta = null;
	BufferedImage vene = null;
	BufferedImage trainer = null;
	BufferedImage club = null;
	BufferedImage fountain = null;
	int allPokemon = 0;
	boolean canGoLeft = true;
	boolean canGoRight = true;
	boolean canGoUp = true;
	boolean canGoDown = true;
	boolean enter;
	boolean inBattle;
	boolean hasPokemon;
	boolean col;
	public PokemonGame() {
		x=600;
		y=60;
		addKeyListener(this);
		setFocusable(true);
		setFocusTraversalKeysEnabled(false);
		requestFocusInWindow();
		revalidate();
		enter = true;
		inBattle=false;
		hasPokemon = false;
		try {
			loudred = ImageIO.read(getClass().getResource("/Sprites/loudredoverworld.png"));
			pik = ImageIO.read(getClass().getResource("/Sprites/pickachu.png"));
			meta = ImageIO.read(getClass().getResource("/Sprites/metapod.png"));
			vene = ImageIO.read(getClass().getResource("/Sprites/venusaur.png"));
			trainer = ImageIO.read(getClass().getResource("/Sprites/trainer.png"));
			club = ImageIO.read(getClass().getResource("/Sprites/musicCenter.png"));
			fountain = ImageIO.read(getClass().getResource("/Sprites/fountain.png"));
		} catch (IOException e1) {
		
			e1.printStackTrace();
		}
		setBackground(Color.DARK_GRAY);
		try {
			setLeft();
			setBackground();
			setUp();
		} catch (IOException e) {

			e.printStackTrace();
		}
	}
	public void setPosClub() {
		x = 700;
		y=700;
	}
	public void setBackground() throws IOException {
		grass = ImageIO.read(getClass().getResource("/Sprites/grass_tile.png"));
		center = ImageIO.read(getClass().getResource("/Sprites/Center.png"));
	}
	public void setLeft() throws IOException {

		x=x-60; 
		
		player = ImageIO.read(getClass().getResource("/Sprites/left.png"));
	}
	public void setRight() throws IOException {

		x=x+60;
		
		player = ImageIO.read(getClass().getResource("/Sprites/right.png"));
	}
	public void setUp() throws IOException {
	
		y=y+60;
		
		player = ImageIO.read(getClass().getResource("/Sprites/front.png"));
	}
	public void setDown() throws IOException {
	
		y=y-60;
		
		player = ImageIO.read(getClass().getResource("/Sprites/back.png"));
	}

	public void paintComponent(Graphics g) {
		
		super.paintComponent(g);
		//Draw Player & Background
		if(allPokemon == 3) {
			Title t = new Title();
			t.gameOver();
		}
		g.drawImage(grass,0,0,null);
		g.drawImage(center, 500, 300, null);
		g.drawImage(player, x, y, null);
		if(hasPokemon) {
			
		g.drawImage(fountain,700,20,null);
		g.drawImage(club,200,50,null);
		}
		g.setColor(Color.black);
		if(col) {
		g.fillRect(0, 0, 50,5000);
		g.fillRect(1140, 0, 50,5000);
		g.fillRect(50, 700, 5000,5000);
		g.fillRect(50, 00, 5000,50);
		}
		if(hasPokemon && !inBattle) {
			g.drawImage(trainer, 300,600,null);
		}
		Rectangle player = new Rectangle(x,y,32,32);
		Rectangle center = new Rectangle(500,300,100,100);
		Rectangle club = new Rectangle(200,50,256,192);
		Rectangle colUp = new Rectangle(50,00,5000,50);
		Rectangle colDown = new Rectangle(50,700,5000,5000);
		Rectangle colLeft = new Rectangle(0, 0, 50,5000);
		Rectangle colRight = new Rectangle(1140,0,50,5000);
		Rectangle fountain = new Rectangle(700,20,200,200);
		if(hasPokemon) {
		Rectangle trainer = new Rectangle(300,600,32,32);
		
		if(player.intersects(trainer) && !inBattle) {
			inBattle = true;
			System.out.println("Battle Begun");
			Title t = new Title();
			t.BattleState();
		}
		if(player.intersects(club)) {
			System.out.println("Inside Club");
			x=600;
			y=60; 
			Title t = new Title();
			t.ClubState();
		}
		if(player.intersects(fountain)) {
			System.out.println("Inside Club");
			x=600;
			y=60; 
			Title t = new Title();
			t.BattleState3();
		}
		}

		if(colUp.intersects(player)) {
			canGoUp = false;
			System.out.println("Col=true");
		}
		if(player.intersects(colDown)) {
			canGoDown = false;
		}
		if(player.intersects(colLeft)) {
			System.out.println("Col=true");
			canGoLeft = false;
		}
		if(player.intersects(colRight)) {
			canGoRight = false;
		}
		
		//Collision
		if(player.intersects(center) && enter) {
			System.out.println("Entered Center");
			Title t = new Title();
			t.CenterState();
			enter=false;
		}

		ChoosePokemon cp = new ChoosePokemon();
		if(cp.getPokemon()==1) {
			g.drawImage(loudred, x+10, y, null);
			hasPokemon = true;
			repaint();
		}
		if(cp.getPokemon()==2) {
			g.drawImage(pik, x+10, y, null);
			hasPokemon = true;
			repaint();
		}
		if(cp.getPokemon()==3) {
			g.drawImage(meta, x+10, y, null);
			hasPokemon = true;
			repaint();
		}
		if(cp.getPokemon()==4) {
			g.drawImage(vene, x+10, y, null);
			hasPokemon = true;
			repaint();
		}

	
	
		
 
		repaint();
	}

	public void keyTyped(KeyEvent e) {

	}
	public void call() {
		PokemonGame pg = new PokemonGame();
	}
	public void updgrade() {
		allPokemon++;
	}
	public void keyPressed(KeyEvent e) {
		
		if(e.getKeyCode()==KeyEvent.VK_RIGHT && canGoRight) {
			CenterState cs = new CenterState();
			cs.getPokemon();
			try {
				enter = true;
				setRight();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			repaint();
		} 
		if(e.getKeyCode()==KeyEvent.VK_LEFT && canGoLeft) {
			CenterState cs = new CenterState();
			cs.getPokemon();
			try {
				enter = true;
				setLeft();
			} catch (IOException e1) {
			
				e1.printStackTrace();
			}
			repaint();
		} 
		if(e.getKeyCode()==KeyEvent.VK_UP && canGoUp) {
			CenterState cs = new CenterState();
			cs.getPokemon();
			try {
				enter = true;
				setDown();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		
			repaint();
		} 

		if(e.getKeyCode()==KeyEvent.VK_DOWN && canGoDown) {
			CenterState cs = new CenterState();
			cs.getPokemon();
			try {
				enter = true;
				setUp();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			repaint();
		} 
	}

	public void keyReleased(KeyEvent e) {
		if(e.getKeyCode()==KeyEvent.VK_C) {
			col = false;
		} 
		if(e.getKeyCode()==KeyEvent.VK_RIGHT) {
			canGoRight = true;
		}
		if(e.getKeyCode()==KeyEvent.VK_UP) {
			canGoUp = true;
		}
		if(e.getKeyCode()==KeyEvent.VK_LEFT) {
			canGoLeft = true;
		}
		if(e.getKeyCode()==KeyEvent.VK_DOWN) {
			canGoDown = true;
		}
	}
}
