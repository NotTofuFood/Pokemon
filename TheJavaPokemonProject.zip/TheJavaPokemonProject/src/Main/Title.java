package Main;


import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

public class Title extends JFrame implements KeyListener {
	public static int GameState = 0;
	static boolean running = false;
	static MenuState menu = new MenuState();
	static PokemonGame pg = new PokemonGame();
	static CenterState cs = new CenterState();
	static BattleState bs = new BattleState();
	static BattleState2 bs2 = new BattleState2();
	static BattleState3 bs3 = new BattleState3();
	static gameOver gameOver = new gameOver();
	static ClubState cl = new ClubState();
	static JFrame f = new JFrame("The Java Pokemon Project");
	private int fps = 60;
	   private int frameCount = 0;
	public static void main(String[] args) {
		state();
		running = true;
		f.setVisible(true);
		f.setSize(1200,800);
		f.setResizable(false);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setLocationRelativeTo(null);
	}
	public Title() {
		addKeyListener(this);
		Thread t = new Thread();
		try {
		//	if(GameState==1) {
			t.sleep(10);
			state();
		//	}
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
	}
	

	public static void state() {
		if(GameState==0) {
			f.add(menu);
			GameState=+1;
			}
		if(GameState==2) {
			f.add(cs);
			
			}
	}
	public void GameState() {
		GameState = 1;
		
		if(GameState==1) {
			f.remove(menu);
			f.remove(cs);
			f.remove(bs);
			f.remove(cl);
			f.remove(bs2);
			f.remove(cs);
			f.remove(bs);
			f.remove(cl);
			f.remove(bs2);
			f.remove(bs3);
			f.add(pg);
		
			f.setVisible(false);
			f.setVisible(true);
			}
		f.revalidate();
	}
	public void gameOver() {
		GameState = 9;
		
		if(GameState==9) {
			f.remove(menu);
			f.remove(cs);
			f.remove(bs);
			f.remove(cl);
			f.remove(bs2);
			f.remove(cs);
			f.remove(bs);
			f.remove(cl);
			f.remove(bs2);
			f.remove(bs3);
			f.remove(pg);
			f.add(gameOver);
			f.setVisible(false);
			f.setVisible(true);
			}
		f.revalidate();
	}
	public void ClubState() {
		GameState = 5;
		
		if(GameState==5) {
			f.remove(menu);
			f.remove(cs);
			f.remove(bs);
			f.remove(bs2);
			f.remove(pg);
			f.remove(bs3);
			f.add(cl);
		
			f.setVisible(false); 
			f.setVisible(true);
			}
		f.revalidate();
	}
	public void bs2() {
		GameState = 6;
		
		if(GameState==6) {
			f.remove(menu);
			f.remove(cs);
			f.remove(bs);
			f.remove(bs2);
			f.remove(pg);
			f.remove(cl);
			f.remove(bs3);
			f.add(bs2);

		
			f.setVisible(false);
			f.setVisible(true);
			}
		f.revalidate();
	}
	public void MenuState() {
		GameState = 0;
	}
	public void CenterState() {
		GameState = 2;
		if(GameState==2) {
			f.remove(bs);
			f.add(cs);
			f.remove(bs2);
			f.remove(bs3);
			f.remove(pg);
			f.setVisible(false);
			f.setVisible(true);
			}
		f.revalidate();
	}
	public void BattleState() {
		GameState = 3;
		if(GameState==3) {
			f.add(bs);
			f.remove(bs2);
			f.remove(cs);
			f.remove(pg);
			f.remove(bs3);
			f.setVisible(false);
			f.setVisible(true);
			}
		f.revalidate();
	}
	public void BattleState3() {
		GameState = 7;
		if(GameState==7) {
			f.add(bs3);
			f.remove(bs2);
			f.remove(cs);
			f.remove(pg);
			f.setVisible(false);
			f.setVisible(true);
			}
		f.revalidate();
	}
	public void keyTyped(KeyEvent e) {
	
	}

	public void keyPressed(KeyEvent e) {
		
	}

	public void keyReleased(KeyEvent e) {
	
	}
}
