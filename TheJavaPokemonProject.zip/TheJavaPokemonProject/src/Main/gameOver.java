package Main;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

public class gameOver extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = -5687398511834314921L;
	int tt = 1;
	boolean enter;
	BufferedImage pokemon;
	BufferedImage title;
	BufferedImage start;
	public gameOver() {

		try {
			pokemon = ImageIO.read(getClass().getResource("/Sprites/AllPokemon.png"));
		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		setFocusable(true);
		setFocusTraversalKeysEnabled(false);
		setBackground(Color.DARK_GRAY);
		enter = true;
	}
	public void paintComponent(Graphics g) {
	super.paintComponent(g);

	//Font title = new Font("Arial",20,80);
	//g.setFont(title);
	g.setColor(Color.BLUE);
	g.drawString("You are the true master Of the Pokemon! (Creator's Message - Thanks for Playing my Game. :) )", 100, 200);
	g.drawImage(pokemon, 100,500, null);

	}

}
